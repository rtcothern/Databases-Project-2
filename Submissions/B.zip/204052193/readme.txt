Partners:
     Name: George Chassiakos
      UID: 204052193
    Email: georgecha@ucla.edu

     Name: Ray Cothern
      UID: 604161519
    Email: rtcothern@gmail.com

Collaboration:
    For parts A and B, we used pair programming to write the
    modifications in person.